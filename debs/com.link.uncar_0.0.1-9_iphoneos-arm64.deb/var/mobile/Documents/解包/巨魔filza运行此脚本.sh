#!/usr/bin/env fish
set car_file "Assets.car"
set script_dir (dirname (status -f))
set output_folder "$script_dir/少年宫"
set bubble_folder "$output_folder/气泡文件"

mkdir -p "$bubble_folder"

if test -e "$car_file"
    uncar "$car_file" "$output_folder"
    echo "初步解包完成！@达康书记亲自解压"
    
    for file in (find "$output_folder" -type f -name 'ChatRoom*')
        set base_name (basename "$file")
        set cleaned_name (echo "$base_name" | sed 's/-[0-9]\{2,3\}-[0-9]\{2,3\}-\(@[0-9]x\)/\1/')
        mv "$file" "$bubble_folder/$cleaned_name"
    end
    
    echo "气泡提取完成！已保存至少年宫由孙连城看管"
else
    echo "错误：文件 $car_file 不存在。"
end