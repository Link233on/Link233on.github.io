#!/var/jb/usr/bin/bash

if [ -f /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib ]; then
    /var/jb/usr/bin/mv /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib.bak
elif [ -f /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib.bak ]; then
    /var/jb/usr/bin/mv /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib.bak /var/jb/Library/MobileSubstrate/DynamicLibraries/FilzaDirProbe.dylib
fi
/var/jb/usr/bin/killall Filza
/var/jb/usr/bin/fdp com.tigisoftware.Filza || :
/var/jb/usr/bin/fdp com.tigisoftware.Filzakalaka || :
